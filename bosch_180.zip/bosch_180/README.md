# Bosch Sensortec BNO055 Zephyr driver

This project contains a simple out of tree implementation of the BNO055 sensor embedded driver to be used with the zephyr rtos.